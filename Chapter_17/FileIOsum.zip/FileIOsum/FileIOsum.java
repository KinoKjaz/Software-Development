/*
Auther: Damion Shakespear
Date Created: 4/8/2025

This assignment is to write a method to create a file named Exercise17_03.dat if it does not exist. Append new data to it if it already exists. 
Write 100 integers created randomly into the file using writeInt(int) in DataOutputStream. Integers are separated by a space.
Write a method that reads the integers from the file and finds the sum of the integers. Assume the file contains an unspecified number of integers.
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class FileIOsum {
   
    public static void main(String[] args) {

        writeFile();
     
        readFile();//Added this method for simple debugging
    }

    public static void writeFile() {
        try {
            DataOutputStream output = new DataOutputStream(new FileOutputStream("Exercise17_03.dat", true));
            
            for (int i = 0; i < 100; i++) {
                output.writeInt((int) (Math.random() * 10));
            } 
            output.close();
        } 
        catch (IOException e) {
            System.out.println("Error could not write to the file.");
            e.printStackTrace();
        }
    }

    public static void readFile() {
        ArrayList<Integer> GotInput = new ArrayList<>();//Added this for simple debugging
        int sumThing = 0;

        try (DataInputStream input = new DataInputStream(new FileInputStream("Exercise17_03.dat"))) {
            while (true) {
                GotInput.add(input.readInt());
            }
        }
        catch (EOFException ex) {
            System.out.print(GotInput);//Added this for simple debugging
            sumThing = GotInput.stream().mapToInt(Integer::intValue).sum();
            System.err.printf("\n%s", sumThing);
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}