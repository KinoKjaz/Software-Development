/*
Auther: Damion Shakespear
Date Created: 4/23/2025

This assignment is to write a program to create a file named Exercise17_01.txt if it does not exist.
Append new data to it if it already exists. Write 100 integers created randomly into the file using text I/O. Integers are separated by a space.
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class FileIO {
   
    public static void main(String[] args) {

        writeFile();
     
        readFile();//Added this method for simple debugging
    }

    public static void writeFile() {
        try {
            DataOutputStream output = new DataOutputStream(new FileOutputStream("Exercise17_01.txt", true));
            
            for (int i = 0; i < 100; i++) {
                output.writeInt((int) (Math.random() * 10));
            } 
            output.close();
        } 
        catch (IOException e) {
            System.out.println("Error could not write to the file.");
            e.printStackTrace();
        }
    }

    public static void readFile() {
        ArrayList<Integer> GotInput = new ArrayList<>();//Added this for simple debugging

        try (DataInputStream input = new DataInputStream(new FileInputStream("Exercise17_01.txt"))) {
            while (true) {
                GotInput.add(input.readInt());
            }
        }
        catch (EOFException ex) {
            System.out.print(GotInput);//Added this for simple debugging
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}