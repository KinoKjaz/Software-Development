/*
Auther: Damion Shakespear
Date Created: 4/23/2025

This assignment is to write a program that prompts the user to enter an input file name and an output file name and saves the encrypted version of the input file to the output file.
Encode the file by adding 5 to every byte in the file.

To test use: Exercise17_14.dat
Tested output was: EncryptTest.dat
 */
import java.io.*;
import java.util.Scanner;

public class EncryptFile {

    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

        System.out.print("Please type the file to be Encrypted: ");
        String ToEncrypt = input.nextLine();
        System.out.print("Please type a name for the Encrypted file: ");
        String Encrypted = input.nextLine();

        try (FileInputStream fileIn = new FileInputStream(ToEncrypt);
             FileOutputStream fileOut = new FileOutputStream(Encrypted)) {

            int readFile;
            while ((readFile = fileIn.read()) != -1) {  
                fileOut.write(readFile + 5);
            }

            System.out.println("File Encrypted");
        }
        catch (IOException e) {
            System.err.println("Error while encrypting file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}