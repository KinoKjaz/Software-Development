/*
Auther: Damion Shakespear
Date Created: 4/23/2025

This assignment is to write a program that prompts the user to enter an input file name for the encrypted file 
and an output file name to decode a version of the input file.
Decode the file by subtracting 5 to every byte in the file.

The file to test this with is obtained from EncryptFile using Exercise17_14.dat.
To test use: EncryptTest.dat
Tested output was: DecodeTest.dat
 */
import java.io.*;
import java.util.Scanner;

public class DecodeFile {

    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

        System.out.print("Please type the file to Decode: ");
        String Encrypted = input.nextLine();
        System.out.print("Please type a name for the Decoded file: ");
        String Decode = input.nextLine();

        try (FileInputStream fileIn = new FileInputStream(Encrypted);
             FileOutputStream fileOut = new FileOutputStream(Decode)) {

            int readFile;
            while ((readFile = fileIn.read()) != -1) {  
                fileOut.write(readFile - 5);
            }

            System.out.println("File Decoded");
        }
        catch (IOException e) {
            System.err.println("Error while encrypting file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
