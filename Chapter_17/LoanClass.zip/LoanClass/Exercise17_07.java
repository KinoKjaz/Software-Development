/*
Auther: Damion Shakespear
Date Created: 4/23/2025

This assignment is to rewrite the given Loan class to implement Serializable.
Modify Exercise17_07 by adding a void function called outputData that reads the Loan objects from the file and displays the total loan amount.
 *
 *  THE FOLLOWING EXISTED------------------------------------------------------
 * 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author rmazorow
 */
import java.io.*;
import java.util.ArrayList;

public class Exercise17_07 {
    public static void main(String[] args) throws FileNotFoundException {
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
        
        try (
                ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Exercise17_07.dat"));
        ) {
            output.writeObject(loan1);
            output.writeObject(loan2);
        } 
        catch (IOException ex) {
            System.out.println("File could not be opened");
        }
        outputData();
    }

//New Code Below --------------------------------------------------------------
    public static void outputData() throws FileNotFoundException {
        
        ArrayList<Object> gotInput = new ArrayList<>();

        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("Exercise17_07.dat"))) {
            while (true) {
                try {
                    gotInput.add(input.readObject());
                } catch (EOFException ex) {
                    break;
                }
            }
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        for (Object obj : gotInput) {
                Loan sendLoan = (Loan) obj;
                System.out.println(sendLoan.getLoanAmount());
        }
    }
}